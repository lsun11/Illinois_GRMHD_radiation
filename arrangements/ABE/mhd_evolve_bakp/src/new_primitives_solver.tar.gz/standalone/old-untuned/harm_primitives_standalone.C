// Here is a wrapper for the 2d solver described in Noble et al.  
// It is meant to be an interface with their code.
// Note that it assumes a simple gamma law for the moment.  No hybrid.
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sys/time.h>
#include <math.h>

#define SQR(x) ((x) * (x))
#define INDEX(i,j,k) ((i) + ext[0] *		\
		      ((j) + ext[1] * (k)))

#include "harm_primitives_headers.h"

int main(void)
{
  
  using namespace std;

  int ext[3];
  ifstream file;
  file.open ("data.bin", ios::in | ios::binary);
  file.seekg (0, ios::beg);
  file.read ((char *)ext, 3*sizeof(int));

  double rhobatm; file.read((char*)&rhobatm, 1*sizeof(double));
  double tau_atm; file.read((char*)&tau_atm, 1*sizeof(double));

  printf("%e %e\n",rhobatm,tau_atm);

  double gamma_th; file.read((char*)&gamma_th, 1*sizeof(double));
  int neos;        file.read((char*)&neos,     1*sizeof(int));

  double *gamma_tab = (double *)malloc(sizeof(double)*(neos+1)); file.read((char*)gamma_tab, (neos+1)*sizeof(double));
  double *k_tab     = (double *)malloc(sizeof(double)*(neos+1)); file.read((char*)k_tab,     (neos+1)*sizeof(double));

  double *eps_tab = (double *)malloc(sizeof(double)*neos); file.read((char*)eps_tab, neos*sizeof(double));
  double *rho_tab = (double *)malloc(sizeof(double)*neos); file.read((char*)rho_tab, neos*sizeof(double));
  double *P_tab   = (double *)malloc(sizeof(double)*neos); file.read((char*)P_tab,   neos*sizeof(double));

  int fullsize=ext[0]*ext[1]*ext[2];
  double *X   = (double *)malloc(sizeof(double)*fullsize);   file.read((char*)X, (fullsize)*sizeof(double));
  double *Y   = (double *)malloc(sizeof(double)*fullsize);   file.read((char*)Y, (fullsize)*sizeof(double));
  double *Z   = (double *)malloc(sizeof(double)*fullsize);   file.read((char*)Z, (fullsize)*sizeof(double));
  double *phi = (double *)malloc(sizeof(double)*fullsize); file.read((char*)phi, (fullsize)*sizeof(double));
  double *gxx = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gxx, (fullsize)*sizeof(double));
  double *gxy = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gxy, (fullsize)*sizeof(double));
  double *gxz = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gxz, (fullsize)*sizeof(double));
  double *gyy = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gyy, (fullsize)*sizeof(double));
  double *gyz = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gyz, (fullsize)*sizeof(double));
  double *gzz = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gzz, (fullsize)*sizeof(double));

  double *gupxx = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gupxx, (fullsize)*sizeof(double));
  double *gupxy = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gupxy, (fullsize)*sizeof(double));
  double *gupxz = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gupxz, (fullsize)*sizeof(double));
  double *gupyy = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gupyy, (fullsize)*sizeof(double));
  double *gupyz = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gupyz, (fullsize)*sizeof(double));
  double *gupzz = (double *)malloc(sizeof(double)*fullsize); file.read((char*)gupzz, (fullsize)*sizeof(double));

  double *shiftx = (double *)malloc(sizeof(double)*fullsize); file.read((char*)shiftx, (fullsize)*sizeof(double));
  double *shifty = (double *)malloc(sizeof(double)*fullsize); file.read((char*)shifty, (fullsize)*sizeof(double));
  double *shiftz = (double *)malloc(sizeof(double)*fullsize); file.read((char*)shiftz, (fullsize)*sizeof(double));

  double *lapm1 = (double *)malloc(sizeof(double)*fullsize); file.read((char*)lapm1, (fullsize)*sizeof(double));
  
  double *tau      = (double *)malloc(sizeof(double)*fullsize); file.read((char*)tau,      (fullsize)*sizeof(double));
  double *mhd_st_x = (double *)malloc(sizeof(double)*fullsize); file.read((char*)mhd_st_x, (fullsize)*sizeof(double));
  double *mhd_st_y = (double *)malloc(sizeof(double)*fullsize); file.read((char*)mhd_st_y, (fullsize)*sizeof(double));
  double *mhd_st_z = (double *)malloc(sizeof(double)*fullsize); file.read((char*)mhd_st_z, (fullsize)*sizeof(double));

  double *rho_star = (double *)malloc(sizeof(double)*fullsize); file.read((char*)rho_star, (fullsize)*sizeof(double));

  double *Bx = (double *)malloc(sizeof(double)*fullsize); file.read((char*)Bx,   (fullsize)*sizeof(double));
  double *By = (double *)malloc(sizeof(double)*fullsize); file.read((char*)By,   (fullsize)*sizeof(double));
  double *Bz = (double *)malloc(sizeof(double)*fullsize); file.read((char*)Bz,   (fullsize)*sizeof(double));

  double *vx    = (double *)malloc(sizeof(double)*fullsize); file.read((char*)vx,   (fullsize)*sizeof(double));
  double *vy    = (double *)malloc(sizeof(double)*fullsize); file.read((char*)vy,   (fullsize)*sizeof(double));
  double *vz    = (double *)malloc(sizeof(double)*fullsize); file.read((char*)vz,   (fullsize)*sizeof(double));
  double *P     = (double *)malloc(sizeof(double)*fullsize); file.read((char*)P,    (fullsize)*sizeof(double));
  double *rho_b = (double *)malloc(sizeof(double)*fullsize); file.read((char*)rho_b,(fullsize)*sizeof(double));
  double *h     = (double *)malloc(sizeof(double)*fullsize); file.read((char*)h,    (fullsize)*sizeof(double));
  double *u0    = (double *)malloc(sizeof(double)*fullsize); file.read((char*)u0,   (fullsize)*sizeof(double));

  int checker; file.read((char*)&checker,sizeof(int));
  if(checker!=1063) {printf("File corrupted. Sorry. checker=%d\n",checker);exit(0);}

  file.close();

  struct timeval start, end;
  long mtime, seconds, useconds;
  gettimeofday(&start, NULL);

  int failures=0,font_fixes=0;
  int pointcount=0;
  int failures_inhoriz=0;
  int pointcount_inhoriz=0;
  
  double error_int_numer=0,error_int_denom=0;

  //#pragma omp parallel for reduction(+:failures,pointcount,failures_inhoriz,pointcount_inhoriz) schedule(static)
  for(int k=0;k<ext[2];k++)
    for(int j=0;j<ext[1];j++)
      for(int i=0;i<ext[0];i++) {
	int index = INDEX(i,j,k);

	struct output_primitives new_primitives;
	struct output_stats stats;
	if(isnan(tau[index])) { printf("found nan in tau %d %d %d\n",i,j,k); }
	if(isnan(mhd_st_x[index])) { printf("found nan in msx %d %d %d\n",i,j,k); }
	if(isnan(mhd_st_y[index])) { printf("found nan in msy %d %d %d\n",i,j,k); }
	if(isnan(mhd_st_z[index])) { printf("found nan in msz %d %d %d\n",i,j,k); }
	if(isnan(rho_star[index])) { printf("found nan in rho_star %d %d %d\n",i,j,k); exit(1); }

	double mhd_st_x_orig = mhd_st_x[index];
	double mhd_st_y_orig = mhd_st_y[index];
	double mhd_st_z_orig = mhd_st_z[index];
	double tau_orig = tau[index];
	double rho_star_orig = rho_star[index];



	// If the rho_star fix has been applied, then rho_star was <0, so we reset the primitives to atmosphere.
	int rho_star_fix_applied =  apply_tau_floor_and_rho_star_floor(index,tau_atm,rhobatm,
								       Bx,By,Bz,
								       tau,rho_star,mhd_st_x,mhd_st_y,mhd_st_z,
								       phi,gxx,gxy,gxz,gyy,gyz,gzz,
								       gupxx,gupxy,gupxz,gupyy,gupyz,gupzz, 
								       new_primitives,
								       lapm1,shiftx,shifty,shiftz,
								       neos,rho_tab,P_tab,eps_tab,k_tab,gamma_tab);



	int check=0;
	stats.font_fixed=0;
	if(rho_star_fix_applied==0) {
	  check = harm_primitives_gammalaw_lowlevel(index,X,Y,Z,
						    phi,gxx,gxy,gxz,gyy,gyz,gzz,
						    gupxx,gupxy,gupxz,gupyy,gupyz,gupzz,
						    lapm1,shiftx,shifty,shiftz,
						    Bx,By,Bz,
						    mhd_st_x,mhd_st_y,mhd_st_z,tau,rho_star,
						    vx,vy,vz,P,rho_b,h,u0,
						    rhobatm,tau_atm,
						    neos,rho_tab,P_tab,eps_tab,k_tab,gamma_tab,			      
						    new_primitives,stats);
	} else {
	  //If we have applied a floor to rho_star, then the primitives are set to atmosphere, 
	  //  and all the conservatives have been updated accordingly.
	}

	//printf("%e\n",fabs(tau[index] - tau_orig) + fabs(rho_star[index] - rho_star_orig) +
	//   fabs(mhd_st_x[index] - mhd_st_x_orig) + fabs(mhd_st_y[index] - mhd_st_y_orig) + fabs(mhd_st_z[index] - mhd_st_z_orig));

	//Now we compute the difference between original & new conservatives, for diagnostic purposes:
	error_int_numer += fabs(tau[index] - tau_orig) + fabs(rho_star[index] - rho_star_orig) + 
	  fabs(mhd_st_x[index] - mhd_st_x_orig) + fabs(mhd_st_y[index] - mhd_st_y_orig) + fabs(mhd_st_z[index] - mhd_st_z_orig);
	error_int_denom += tau_orig + rho_star_orig + fabs(mhd_st_x_orig) + fabs(mhd_st_y_orig) + fabs(mhd_st_z_orig);


	if(stats.font_fixed==1) font_fixes++;
	if(check!=0) failures++;
	pointcount++;
	if(exp(phi[index]*6.0)>15.0) {
	  if(check!=0) failures_inhoriz++;
	  pointcount_inhoriz++;
	}

	//Set primitives!
	P[index] = new_primitives.P_new;
	rho_b[index] = new_primitives.rho_b_new;
	u0[index] = new_primitives.u0_new;
	vx[index] = new_primitives.vx_new;
	vy[index] = new_primitives.vy_new;
	vz[index] = new_primitives.vz_new;
	
      }

  gettimeofday(&end, NULL);

  seconds  = end.tv_sec  - start.tv_sec;
  useconds = end.tv_usec - start.tv_usec;
  
  mtime = ((seconds) * 1000 + useconds/1000.0) + 0.999;  // We add 0.999 since mtime is a long int; this rounds up the result before setting the value.  Here, rounding down is incorrect.
  printf("Font fixes: %d / %d = %.3e\tFailures: %d / %d = %.3e, InHoriz: %d / %d = %.3e\t%f solutions/second, Error: %e\n",
	 font_fixes,pointcount,font_fixes/((double)pointcount), 
	 failures,pointcount,failures/((double)pointcount), 
	 failures_inhoriz,pointcount_inhoriz,failures_inhoriz/((double)pointcount_inhoriz+1e-10), 
	 ext[0]*ext[1]*ext[2] / ((double)mtime/1000.0),
	 error_int_numer/error_int_denom);
 
  return 0;
}

#include "harm_primitives_lowlevel.C"
