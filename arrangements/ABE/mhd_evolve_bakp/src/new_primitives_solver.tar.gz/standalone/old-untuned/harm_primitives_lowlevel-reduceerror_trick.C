
#include "harm_primitives_recompute_conservs_rho_star_tau_floor.C"

int harm_primitives_gammalaw_lowlevel(int &index,double *X,double *Y,double *Z,
				      double *phi,double *gxx,double *gxy,double *gxz,double *gyy,double *gyz,double *gzz,
				      double *gupxx,double *gupxy,double *gupxz,double *gupyy,double *gupyz,double *gupzz,
				      double *lapm1,double *shiftx,double *shifty,double *shiftz,
				      double *Bx,double *By,double *Bz,
				      double *mhd_st_x,double *mhd_st_y,double *mhd_st_z,double *tau,double *rho_star,
				      double *vx,double *vy,double *vz,double *P,double *rho_b,double *h,double *u0,
				      double &rhobatm,double &tau_atm,
				      int &neos,double *rho_tab,double *P_tab,double *eps_tab,double *k_tab,double *gamma_tab,				      
				      struct output_primitives &new_primitives,
				      double &tau_diff,double &rho_star_diff,double &mhd_st_x_diff,double &mhd_st_y_diff,double &mhd_st_z_diff) {


  // declare the HARM-style arrays
  FTYPE U[NPR]; 
  FTYPE gcov[NDIM][NDIM]; 
  FTYPE gcon[NDIM][NDIM]; 
  FTYPE detg;
  FTYPE prim[NPR];

  // These are the tentative best guess for our primitives.
  struct output_primitives best_guess_primitives;

  double phiL     = phi[index];
  double Psi      = exp(phiL);
  double Psi4     = Psi*Psi*Psi*Psi;
  double Psi6     = Psi4*Psi*Psi;
  double alpha    = lapm1[index]+1.0;
  double alpha_inv= 1.0/alpha;
  detg     = alpha*Psi6; // detg already declared above, used for HARM
  double shiftxL  = shiftx[index];
  double shiftyL  = shifty[index];
  double shiftzL  = shiftz[index];

  //Define physical metric & its inverse:
  double gxx_physL     = gxx[index]*Psi4;
  double gxy_physL     = gxy[index]*Psi4;
  double gxz_physL     = gxz[index]*Psi4;
  double gyy_physL     = gyy[index]*Psi4;
  double gyz_physL     = gyz[index]*Psi4;
  double gzz_physL     = gzz[index]*Psi4;
  double gupxx_physL   = gupxx[index]/Psi4;
  double gupxy_physL   = gupxy[index]/Psi4;
  double gupxz_physL   = gupxz[index]/Psi4;
  double gupyy_physL   = gupyy[index]/Psi4;
  double gupyz_physL   = gupyz[index]/Psi4;
  double gupzz_physL   = gupzz[index]/Psi4;

  double shift_xL = gxx_physL*shiftxL + gxy_physL*shiftyL + gxz_physL*shiftzL;
  double shift_yL = gxy_physL*shiftxL + gyy_physL*shiftyL + gyz_physL*shiftzL;
  double shift_zL = gxz_physL*shiftxL + gyz_physL*shiftyL + gzz_physL*shiftzL;
  double beta2L   = shift_xL*shiftxL + shift_yL*shiftyL + shift_zL*shiftzL;


  // Note that the factor here gets us to the object
  // referred to as B^i in the Noble et al paper (and
  // apparently also in the comments to their code).
  // This is NOT the \mathcal{B}^i, which differs by 
  // a factor of the lapse.
  double sqrtfourpi_inv      = 1.0/sqrt(4.0*M_PI);
  double BxL       = Bx[index];
  double ByL       = By[index];
  double BzL       = Bx[index];

  double BxL_over_alpha_sqrt_fourpi = BxL*alpha_inv*sqrtfourpi_inv;
  double ByL_over_alpha_sqrt_fourpi = ByL*alpha_inv*sqrtfourpi_inv;
  double BzL_over_alpha_sqrt_fourpi = BzL*alpha_inv*sqrtfourpi_inv;

  // translate 
  double rho_starL  = rho_star[index];
  double tauL       = tau[index];
  double mhd_st_xL  = mhd_st_x[index];
  double mhd_st_yL  = mhd_st_y[index];
  double mhd_st_zL  = mhd_st_z[index];

  double rho_b_oldL = rho_b[index];
  double P_oldL     = P[index];
  double vxL        = vx[index];
  double vyL        = vy[index];
  double vzL        = vz[index];
  double u0L        = u0[index];

  /*
    -- Driver for new prim. var. solver.  The driver just translates
    between the two sets of definitions for U and P.  The user may 
    wish to alter the translation as they see fit.  


    //         /  rho u^t           \                             //
    //    U =  |  T^t_t   + rho u^t |  sqrt(-det(g_{\mu\nu}))     //
    //         |  T^t_i             |                             //
    //         \   B^i              /                             //
    //                                                            //
    //        /    rho        \                                   //
    //    P = |    uu         |                                   //
    //        | \tilde{u}^i   |                                   //
    //        \   B^i         /                                   //

    (above equations have been fixed by Yuk Tung & Zach)
  */
  
  // U[NPR]    = conserved variables (current values on input/output);
  // gcov[NDIM][NDIM] = covariant form of the metric ;
  // gcon[NDIM][NDIM] = contravariant form of the metric ;
  // gdet             = sqrt( - determinant of the metric) ;
  // prim[NPR] = primitive variables (guess on input, calculated values on 
  //	 			    output if there are no problems);

  // U[1]   =  
  // U[2-4] =  stildei + rhostar
		    
  gcov[0][0] = -alpha*alpha + beta2L;
  gcov[0][1] = shift_xL;
  gcov[0][2] = shift_yL;
  gcov[0][3] = shift_zL;
  gcov[1][1] = gxx_physL;
  gcov[1][2] = gxy_physL;
  gcov[1][3] = gxz_physL;
  gcov[2][2] = gyy_physL;
  gcov[2][3] = gyz_physL;
  gcov[3][3] = gzz_physL;
  gcov[1][0] = gcov[0][1];
  gcov[2][0] = gcov[0][2];
  gcov[3][0] = gcov[0][3];
  gcov[2][1] = gcov[1][2];
  gcov[3][1] = gcov[1][3];
  gcov[3][2] = gcov[2][3];
		    
  gcon[0][0] = -1.0/(alpha*alpha);
  gcon[0][1] = shiftxL/(alpha*alpha);
  gcon[0][2] = shiftyL/(alpha*alpha);
  gcon[0][3] = shiftzL/(alpha*alpha);
  gcon[1][1] = gupxx_physL - shiftxL*shiftxL/(alpha*alpha);
  gcon[1][2] = gupxy_physL - shiftxL*shiftyL/(alpha*alpha);
  gcon[1][3] = gupxz_physL - shiftxL*shiftzL/(alpha*alpha);
  gcon[2][2] = gupyy_physL - shiftyL*shiftyL/(alpha*alpha);
  gcon[2][3] = gupyz_physL - shiftyL*shiftzL/(alpha*alpha);
  gcon[3][3] = gupzz_physL - shiftzL*shiftzL/(alpha*alpha);
  gcon[1][0] = gcon[0][1];
  gcon[2][0] = gcon[0][2];
  gcon[3][0] = gcon[0][3];
  gcon[2][1] = gcon[1][2];
  gcon[3][1] = gcon[1][3];
  gcon[3][2] = gcon[2][3];

  double tau_orig = tauL;
  double rho_star_orig = rho_starL;
  double mhd_st_x_orig = mhd_st_xL;
  double mhd_st_y_orig = mhd_st_yL;
  double mhd_st_z_orig = mhd_st_zL;

  //This prevents NaN's later on when we calculate the _diff variables
  //if(fabs(mhd_st_x_orig)<1e-100) mhd_st_x_orig=1e-100;
  //if(fabs(mhd_st_y_orig)<1e-100) mhd_st_y_orig=1e-100;
  //if(fabs(mhd_st_z_orig)<1e-100) mhd_st_z_orig=1e-100;

  double GAMMA_SPEED_LIMIT = 100.0;

  bool found_first_success = false;
  bool found_subsequent_success = false;
  int num_ratchet_failures=0;
  int num_iterations=0;
  // We find that 0.85 is a good value with MAX_RATCHET_FAILURES set to 20.
#define TOL_DECREASE_FACTOR 0.8
#define MAX_RATCHET_FAILURES_PLUSONE 1
  double TOL_INCREASE_FACTOR = pow(1.0/TOL_DECREASE_FACTOR,1.0/(MAX_RATCHET_FAILURES_PLUSONE));
  double TOL=1.0;

  double mhd_st_x_delta = 1e-100;
  double mhd_st_y_delta = 1e-100;
  double mhd_st_z_delta = 1e-100;
  while(1==1) {
    for(double mhd_st_z_change=0;mhd_st_z_change<2.01;mhd_st_z_change+=1.0) 
      for(double mhd_st_y_change=0;mhd_st_y_change<2.01;mhd_st_y_change+=1.0) 
	for(double mhd_st_x_change=0;mhd_st_x_change<2.01;mhd_st_x_change+=1.0) 
	  for(int which_guess=0;which_guess<2;which_guess++) {
	    
	    int check;

	    // Reset the found_subsequent_success flag.
	    if(mhd_st_x_change==0 && mhd_st_y_change==0 && mhd_st_z_change==0) found_subsequent_success = false;

	    if(which_guess==1) {
	      //Use a different initial guess:
	      rho_b_oldL = rho_starL/Psi6;
	      // GAMMA=2 ONLY:
	      P_oldL     = rho_b_oldL*rho_b_oldL;
	      u0L = alpha_inv;
	      vxL = -shiftxL;
	      vyL = -shiftyL;
	      vzL = -shiftzL;
	    }

	    if(which_guess==2) {
	      //Use atmosphere as initial guess:
	      rho_b_oldL = 100.0*rhobatm;
	      // GAMMA=2 ONLY:
	      P_oldL     = rho_b_oldL*rho_b_oldL;
	      u0L = alpha_inv;
	      vxL = -shiftxL;
	      vyL = -shiftyL;
	      vzL = -shiftzL;

	      u0L = 1.0;
	      vxL = 0.0;
	      vyL = 0.0;
	      vzL = 0.0;
	    }

	    // Fill the array of conserved variables according to the wishes of Utoprim_2d.
	    U[RHO]    = rho_starL;
	    U[UU]     = -tauL*alpha+(1.0-alpha)*rho_starL + shiftxL*mhd_st_xL + shiftyL*mhd_st_yL  + shiftzL*mhd_st_zL ; // note the minus sign on tauL!
	    U[UTCON1] = mhd_st_xL;
	    U[UTCON2] = mhd_st_yL;
	    U[UTCON3] = mhd_st_zL;
	    U[BCON1]  = detg*BxL_over_alpha_sqrt_fourpi;
	    U[BCON2]  = detg*ByL_over_alpha_sqrt_fourpi;
	    U[BCON3]  = detg*BzL_over_alpha_sqrt_fourpi;

	    double uL = P_oldL/(GAMMA - 1.0);
	    double utxL = u0L*(vxL + shiftxL);
	    double utyL = u0L*(vyL + shiftyL);
	    double utzL = u0L*(vzL + shiftzL);

	    prim[RHO]    = rho_b_oldL;
	    prim[UU]     = uL;
	    prim[UTCON1] = utxL;
	    prim[UTCON2] = utyL;
	    prim[UTCON3] = utzL;
	    prim[BCON1]  = BxL_over_alpha_sqrt_fourpi;
	    prim[BCON2]  = ByL_over_alpha_sqrt_fourpi;
	    prim[BCON3]  = BzL_over_alpha_sqrt_fourpi;

	    /*************************************************************/
	    // CALL HARM PRIMITIVES SOLVER:
	    check = Utoprim_2d(U, gcov, gcon, detg, prim);
	    // Note that we have modified this solver, so that nearly 100% 
	    // of the time it yields either a good root, or a root with 
	    // negative epsilon (i.e., pressure).  We fix the root below
	    // & compute the change in conservatives, if any.  If there
	    // is > 1e-10 change, we perturb the conservative & continue
	    // until we cannot find a better root.
	    /*************************************************************/

	    //if(check==0 || check==5 || (check==101 && rho_starL/Psi6<rhobatm*1e4)) {
	    if(check==0 || check==5 || (check==101)) {
	    //if(check==0 || check==5) {
	      //Now that we have found some solution, we first set the best_guess_primitives struct & limit velocity:

	      double u_x_new,u_y_new,u_z_new,au0m1; // <- needed below for recomputing conservatives

	      best_guess_primitives.rho_b_new = prim[RHO];
	      best_guess_primitives.P_new = (GAMMA-1.0)*prim[UU];
    
	      double utx_new = prim[UTCON1];
	      double uty_new = prim[UTCON2];
	      double utz_new = prim[UTCON3];

	      //Velocity limiter:
	      double gijuiuj = gxx_physL*SQR(utx_new ) +
		2.0*gxy_physL*utx_new*uty_new + 2.0*gxz_physL*utx_new*utz_new +
		gyy_physL*SQR(uty_new) + 2.0*gyz_physL*uty_new*utz_new +
		gzz_physL*SQR(utz_new);
	      au0m1 = gijuiuj/( 1.0+sqrt(1.0+gijuiuj) );
	      best_guess_primitives.u0_new = (au0m1+1.0)*alpha_inv;
	      // *** Limit velocity
	      if (au0m1 > GAMMA_SPEED_LIMIT-1.0) {
		double fac = sqrt((SQR(GAMMA_SPEED_LIMIT)-1.0)/(SQR(1.0+au0m1) - 1.0));
		utx_new *= fac;
		uty_new *= fac;
		utz_new *= fac;
		gijuiuj = gijuiuj * SQR(fac);
		au0m1 = gijuiuj/( 1.0+sqrt(1.0+gijuiuj) );
		// Reset rho_b and u0
		best_guess_primitives.u0_new = (au0m1+1.0)*alpha_inv;
		best_guess_primitives.rho_b_new = rho_star[index]/(alpha*best_guess_primitives.u0_new*Psi6);
	      }

	      best_guess_primitives.vx_new  = utx_new/best_guess_primitives.u0_new - shiftxL;
	      best_guess_primitives.vy_new  = uty_new/best_guess_primitives.u0_new - shiftyL;
	      best_guess_primitives.vz_new  = utz_new/best_guess_primitives.u0_new - shiftzL;
	      u_x_new = gxx_physL*utx_new + gxy_physL*uty_new + gxz_physL*utz_new;
	      u_y_new = gxy_physL*utx_new + gyy_physL*uty_new + gyz_physL*utz_new;
	      u_z_new = gxz_physL*utx_new + gyz_physL*uty_new + gzz_physL*utz_new;

	      //Next we floor rho_b & P:

	      //First set atmosphere cap on rho_b:
	      if(best_guess_primitives.rho_b_new<rhobatm) best_guess_primitives.rho_b_new=rhobatm;
	      //Next set floor on P:
	      //FIXME: GAMMA=2 ONLY:
	      if(GAMMA!=2.0) {printf("This primitives solver isn't ready for GAMMA!=2.0 yet.\n"); exit(1); }
	      double P_cold = best_guess_primitives.rho_b_new*best_guess_primitives.rho_b_new;
	      if(best_guess_primitives.P_new<0.9*P_cold) {
		best_guess_primitives.P_new=0.9*P_cold;
	      }

	      //Now that P and possibly rho_b have been changed, recompute conservatives:
	      recompute_conservatives_fast(best_guess_primitives,
					   Psi6,alpha,
					   gxx_physL,gxy_physL,gxz_physL,gyy_physL,gyz_physL,gzz_physL,
					   gupxx_physL,gupxy_physL,gupxz_physL,gupyy_physL,gupyz_physL,gupzz_physL,
					   BxL,ByL,BzL,
					   rho_starL,tauL,mhd_st_xL,mhd_st_yL,mhd_st_zL,
					   u_x_new,u_y_new,u_z_new,au0m1);

	      check=0;  //check==0 implies that we are successful.  We assume success until proven otherwise. (e.g., conserv changed too much)

	      double new_mhd_st_x_delta = fabs(mhd_st_xL - mhd_st_x_orig);
	      double new_mhd_st_y_delta = fabs(mhd_st_yL - mhd_st_y_orig);
	      double new_mhd_st_z_delta = fabs(mhd_st_zL - mhd_st_z_orig);

	      

	      // Here we reset mhd_st_i_delta's if they are smaller than the old versions.
	      // The goal is to ratchet these down as much as possible.
	      // Note that mhd_st_x_delta=1e-100 initially.
	      if( mhd_st_x_delta==1e-100 ||
		  ( sqrt(SQR(new_mhd_st_x_delta) + SQR(new_mhd_st_y_delta) + SQR(new_mhd_st_z_delta)) < 
		    0.99*sqrt(SQR(mhd_st_x_delta) + SQR(mhd_st_y_delta) + SQR(mhd_st_z_delta)) && rho_starL/Psi6>100.0*rhobatm ) ) {

		mhd_st_x_delta = new_mhd_st_x_delta;
		mhd_st_y_delta = new_mhd_st_y_delta;
		mhd_st_z_delta = new_mhd_st_z_delta;

		//Conservatives are now better than the old conservatives guess, or at least consistent with the primitives.
		//  Thus, we save the latest conservatives & primitives here.
		//if(found_first_success==false || check==0) {
		tau[index] = tauL;
		rho_star[index] = rho_starL;
		mhd_st_x[index] = mhd_st_xL;
		mhd_st_y[index] = mhd_st_yL;
		mhd_st_z[index] = mhd_st_zL;
		found_first_success = true;

		new_primitives.rho_b_new  = best_guess_primitives.rho_b_new;
		new_primitives.P_new      = best_guess_primitives.P_new;
		new_primitives.u0_new     = best_guess_primitives.u0_new;
		new_primitives.vx_new     = best_guess_primitives.vx_new;
		new_primitives.vy_new     = best_guess_primitives.vy_new;
		new_primitives.vz_new     = best_guess_primitives.vz_new;

		//Next compute the normalized difference between original & new conservatives.
		tau_diff      = fabs(tauL - tau_orig)          /fabs(tau_orig);
		rho_star_diff = fabs(rho_starL - rho_star_orig)/fabs(rho_star_orig);
		mhd_st_x_diff = new_mhd_st_x_delta/fabs(mhd_st_x_orig+1e-200);
		mhd_st_y_diff = new_mhd_st_y_delta/fabs(mhd_st_y_orig+1e-200);
		mhd_st_z_diff = new_mhd_st_z_delta/fabs(mhd_st_z_orig+1e-200);

		// If we have changed the conservatives only at the 10th decimal place or better, we accept the solution.
		if(mhd_st_x_diff<1e-10 && mhd_st_y_diff<1e-10 && mhd_st_z_diff<1e-10)  return 0;

		// Reset the change counters & look again, for a new root that minimizes the diff's.
		mhd_st_x_change=3.5; mhd_st_y_change=3.5; mhd_st_z_change=3.5; which_guess=0;

		//Some success is good, but let's try for a root that is even closer to the original conservatives.
		// Set this multiplicative factor closer to (but always less than) 1.0 for (possibly) more accuracy at the cost of speed.
		TOL *= TOL_DECREASE_FACTOR;
		found_subsequent_success = true; // <- note that we reset this at the top of the function.  It's only used below to determine if we should exit this func.
	      }

	      // Set next primitives guess (which_guess=0 case) to speed up the root finder & improve its accuracy.
	      rho_b_oldL = best_guess_primitives.rho_b_new;
	      P_oldL = best_guess_primitives.P_new/(GAMMA-1.0);
	      u0L    = best_guess_primitives.u0_new;
	      vxL    = best_guess_primitives.vx_new;
	      vyL    = best_guess_primitives.vy_new;
	      vzL    = best_guess_primitives.vz_new;
	    }

	    if(found_subsequent_success==false) {
	      //If the conservatives didn't improve, then try again:

	      // Here is where we ratchet down the conservatives, attempting to find values that are closer
	      //   to the originals.
	      // The _change variables go {0,1,2}, but we want the loop to go: 0 (unchanged), -1, and then 1, 
	      //   so we use j = 0.5 i (3 i - 5), where i is the _change variable, so i={0,1,2} yields j={0,-1,1}.
	      mhd_st_xL = mhd_st_x_orig + mhd_st_x_delta*TOL*0.5*mhd_st_x_change*(3*mhd_st_x_change-5);
	      mhd_st_yL = mhd_st_y_orig + mhd_st_y_delta*TOL*0.5*mhd_st_y_change*(3*mhd_st_y_change-5);
	      mhd_st_zL = mhd_st_z_orig + mhd_st_z_delta*TOL*0.5*mhd_st_z_change*(3*mhd_st_z_change-5);

	    }

	    num_iterations++;

	    //We set the rules here for leaving this function.  In order to leave 
	    // successfully, we must have already set the primitives & conservatives, 
	    // and when we ratcheted down TOL, we were eventually unable to find a root.
	    if(mhd_st_x_change>1.5 && mhd_st_y_change>1.5 && mhd_st_z_change>1.5) {
	      // We find that 0.98 is a good value with MAX_RATCHET_FAILURES_PLUSONE set to 20.
	      if(found_subsequent_success==false) { TOL*=TOL_INCREASE_FACTOR; num_ratchet_failures++; }

	      if(found_first_success==true && found_subsequent_success==false && num_ratchet_failures>MAX_RATCHET_FAILURES_PLUSONE-1) return 0;

	      if(found_first_success==false) {
		printf("FAILURE... iters=%d index=%d check: %d \t %e %e %e %e %e mhd_st_x_orig = %e\n",
		       num_iterations,index,check,rho_starL,tauL,mhd_st_xL,mhd_st_yL,mhd_st_zL,mhd_st_x_orig);
		printf("rho_star_orig,rho_starL = %e %e rhob_est %e < %e ?\n",rho_star_orig,rho_starL,rho_starL/Psi6,rhobatm*1e6);

		return 1;
	      } 
	    }
	  }
  }
}

#include "harm_u2p_util.c"
#include "harm_utoprim_2d.c"
