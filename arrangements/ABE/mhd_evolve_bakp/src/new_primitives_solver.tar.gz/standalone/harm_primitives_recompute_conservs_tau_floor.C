#define SQR(x) ((x) * (x))

void eigenvalues_3by3_real_sym_matrix(double & lam1, double & lam2, double & lam3,
         double M11, double M12, double M13, double M22, double M23, double M33);

int apply_tau_floor(int &index,double &tau_atm,double &rhobatm,
		    double *Bx,double *By,double *Bz,
		    double *tau,double *rho_star,double *mhd_st_x,double *mhd_st_y,double *mhd_st_z,
		    double *phi,double *gxx,double *gxy,double *gxz,double *gyy,double *gyz,double *gzz,
		    double *gupxx,double *gupxy,double *gupxz,double *gupyy,double *gupyz,double *gupzz,
		    struct output_primitives &new_primitives,
		    double *lapm1,double *shiftx,double *shifty,double *shiftz,
		    int &neos,double *rho_tab,double *P_tab,double *eps_tab,double *k_tab,double *gamma_tab,
		    double &Psi6threshold) {
  
  double Psi2 = exp(2.0*phi[index]);
  double Psi4 = Psi2*Psi2;
  double Psi6 = Psi4*Psi2;
  double Psim4 = 1.0/Psi4;

  double gamma = gamma_tab[0];
  double kpoly = k_tab[0];
  int gamma_equals2 = 1;
  if (fabs(gamma-2.0) > 1.e-10) gamma_equals2 = 0;

  //First apply the rho_star floor:

  //rho_star = alpha u0 Psi6 rho_b, alpha u0 > 1, so if rho_star < Psi6 rhobatm, then we are GUARANTEED that we can reset to atmosphere.
  //if(rho_star[index] < 1e4*Psi6*rhobatm) {
  //if(rho_star[index] < 2*Psi6*rhobatm) {
  double gxxL = gxx[index];
  double gxyL = gxy[index];
  double gxzL = gxz[index];
  double gyyL = gyy[index];
  double gyzL = gyz[index];
  double gzzL = gzz[index];

  double lam1,lam2,lam3;
  eigenvalues_3by3_real_sym_matrix(lam1, lam2, lam3,gxxL, gxyL, gxzL, gyyL, gyzL, gzzL);

  double gxxi=gupxx[index]*Psim4,gyyi=gupyy[index]*Psim4,gzzi=gupzz[index]*Psim4,gxyi=gupxy[index]*Psim4,gxzi=gupxz[index]*Psim4,gyzi=gupyz[index]*Psim4;

  if (lam1 < 0.0 || lam2 < 0.0 || lam3 < 0.0) {
     // Metric is not positive-defitive, reset the metric to be conformally-flat.
     gxxL = 1.0;
     gxyL = 0.0;
     gxzL = 0.0;
     gyyL = 1.0;
     gyzL = 0.0;
     gzzL = 1.0;
     gxxi = Psim4;
     gxyi = 0.0;
     gxzi = 0.0;
     gyyi = Psim4;
     gyzi = 0.0;
     gzzi = Psim4;
  }

  /* DO NOT UNCOMMENT THESE LINES; THIS IS A TERRIBLE PRESCRIPTION.
     if(rho_star[index] < 0.0) {
     new_primitives.rho_b_new = rhobatm;

     //    printf("rhostar negative! %e\n",rho_star[index]);
    
     double P_cold,eps_cold;
     if (gamma_equals2==1) {
     P_cold = kpoly*new_primitives.rho_b_new*new_primitives.rho_b_new;
     eps_cold = kpoly*new_primitives.rho_b_new;
     } else {
     P_cold = kpoly*pow(new_primitives.rho_b_new,gamma);
     eps_cold = P_cold/( (gamma-1.0)*new_primitives.rho_b_new );
     }

     new_primitives.P_new = P_cold;

     double BxL = Bx[index];
     double ByL = By[index];
     double BzL = Bz[index];

     double B2 =  Psi4*(gxxL*SQR(BxL) +
     2.0*gxyL*BxL*ByL +
     2.0*gxzL*BxL*BzL +
     gyyL*SQR(ByL) +
     2.0*gyzL*ByL*BzL +
     gzzL*SQR(BzL) ) ;

     new_primitives.u0_new = 1.0/(lapm1[index]+1.0);
     new_primitives.vx_new = -shiftx[index];
     new_primitives.vy_new = -shifty[index];
     new_primitives.vz_new = -shiftz[index];
    
     double f1o4p = 1.0/(4.0*M_PI);
     double sb2 = B2*f1o4p;
     double eps = eps_cold;
     tau[index]   = Psi6*(new_primitives.rho_b_new*eps + sb2*0.5);

     mhd_st_x[index] = 0.0;
     mhd_st_y[index] = 0.0;
     mhd_st_z[index] = 0.0;
     rho_star[index] = rhobatm*Psi6;

     // HORRIBLE! DON'T DO THIS; WE STILL HAVE MORE FIXES TO APPLY!
     return 1;
     }
  */

  //Next, prepare for the tau and stilde fixes:

  double f1os4p = 1.0/sqrt(4.0*M_PI);
  double Bxbar = Bx[index]*f1os4p,Bybar = By[index]*f1os4p,Bzbar = Bz[index]*f1os4p;

  double gxx_physL=gxxL*Psi4,gyy_physL=gyyL*Psi4,gzz_physL=gzzL*Psi4,gxy_physL=gxyL*Psi4,gxz_physL=gxzL*Psi4,gyz_physL=gyzL*Psi4;
  double Bbar_x = gxx_physL*Bxbar + gxy_physL*Bybar + gxz_physL*Bzbar;
  double Bbar_y = gxy_physL*Bxbar + gyy_physL*Bybar + gyz_physL*Bzbar;
  double Bbar_z = gxz_physL*Bxbar + gyz_physL*Bybar + gzz_physL*Bzbar;
  double Bbar2 = Bxbar*Bbar_x + Bybar*Bbar_y + Bzbar*Bbar_z;
  double Bbar = sqrt(Bbar2);
  double check_B_small = fabs(Bxbar)+fabs(Bybar)+fabs(Bzbar);
  if (check_B_small>0 && check_B_small<1.e-150) {
     // need to compute Bbar specially to prevent floating-point underflow
     double Bmax = fabs(Bxbar);
     if (Bmax < fabs(Bybar)) Bmax=fabs(Bybar);
     if (Bmax < fabs(Bzbar)) Bmax=fabs(Bzbar);
     double Bxtmp=Bxbar/Bmax, Bytemp=Bybar/Bmax, Bztemp=Bzbar/Bmax;
     double B_xtemp=Bbar_x/Bmax, B_ytemp=Bbar_y/Bmax, B_ztemp=Bbar_z/Bmax;
     Bbar = sqrt(Bxtmp*B_xtemp + Bytemp*B_ytemp + Bztemp*B_ztemp)*Bmax;
  }
  double stxi=mhd_st_x[index],styi=mhd_st_y[index],stzi=mhd_st_z[index];
  double BbardotS = Bxbar*stxi + Bybar*styi + Bzbar*stzi;
  double hatBbardotS = BbardotS/Bbar;
  if (Bbar<1.e-300) hatBbardotS = 0.0;

  double rho_s = rho_star[index];

  // Limit hatBbardotS
  //double max_gammav = 100.0;
  //double rhob_max = rho_s/Psi6;
  //double hmax = 1.0 + 2.0*rhob_max;
  //double abs_hatBbardotS_max = sqrt(SQR(max_gammav)-1.0)*rho_s*hmax;
  //if (fabs(hatBbardotS) > abs_hatBbardotS_max) {
  //   double fac_reduce = abs_hatBbardotS_max/fabs(hatBbardotS);
  //   double hatBbardotS_max = hatBbardotS*fac_reduce;
  //   double Bbar_inv = 1.0/Bbar;
  //   double hat_Bbar_x = Bbar_x*Bbar_inv;
  //   double hat_Bbar_y = Bbar_y*Bbar_inv;
  //   double hat_Bbar_z = Bbar_z*Bbar_inv;
  //   double sub_fact = hatBbardotS_max - hatBbardotS;
  //   stxi += sub_fact*hat_Bbar_x;
  //   styi += sub_fact*hat_Bbar_y;
  //   stzi += sub_fact*hat_Bbar_z;
  //   hatBbardotS = hatBbardotS_max;
  //   BbardotS *= fac_reduce;
  //   mhd_st_x[index] = stxi; mhd_st_y[index] = styi; mhd_st_z[index] = stzi;
  //}

  double sdots= gxxi*SQR(stxi)+gyyi*SQR(styi)+gzzi*SQR(stzi)+2.0*
      (gxyi*stxi*styi+gxzi*stxi*stzi+gyzi*styi*stzi);

  double Wm = sqrt(SQR(hatBbardotS)+ SQR(rho_s))/Psi6;
  double Sm2 = (SQR(Wm)*sdots + SQR(BbardotS)*(Bbar2+2.0*Wm))/SQR(Wm+Bbar2);
  double Wmin = sqrt(Sm2 + SQR(rho_s))/Psi6;
  double sdots_fluid_max = sdots;

  //tau fix, applicable when B==0 and B!=0:
  if(tau[index] < 0.5*Psi6*Bbar2) {
    tau[index] = tau_atm+0.5*Psi6*Bbar2;
  }

  double tau_fluid_min = tau[index] - 0.5*Psi6*Bbar2 - (Bbar2*sdots - SQR(BbardotS))*0.5/(Psi6*SQR(Wmin+Bbar2));
  
  //Apply Stilde fix when B==0.
  //if(Bx[index]==0 && By[index]==0 && Bz[index]==0 && (Psi6>30.0 || rho_star[index]/Psi6<100*rhobatm)) {
  //if(check_B_small < 1.e-300) {
  double Patm;
  if (gamma_equals2==1) { 
     Patm = kpoly*rhobatm*rhobatm;
  } else {
     Patm = kpoly*pow(rhobatm,gamma);
  }
  if(check_B_small*check_B_small < Patm*1e-32) {
    double rhot=tau[index]*(tau[index]+2.0*rho_s);
    double safetyfactor = 0.999999;
    //if(Psi6>Psi6threshold) safetyfactor=0.99;

    if(sdots > safetyfactor*rhot) {
      double rfactm1 = sqrt((safetyfactor*rhot)/sdots);
      mhd_st_x[index]=mhd_st_x[index]*rfactm1;
      mhd_st_y[index]=mhd_st_y[index]*rfactm1;
      mhd_st_z[index]=mhd_st_z[index]*rfactm1;
    }
   } else if(Psi6>Psi6threshold) {
     //Apply new Stilde fix.
     if (tau_fluid_min < tau_atm*1.001) { 
        tau_fluid_min = tau_atm*1.001;
        tau[index] = tau_fluid_min + 0.5*Psi6*Bbar2 + (Bbar2*sdots - SQR(BbardotS))*0.5/(Psi6*SQR(Wmin+Bbar2));
     }
     double tauL = tau[index];
     double rho_starL = rho_star[index];

     double LHS = tau_fluid_min*(tau_fluid_min+2.0*rho_starL);
     double RHS = sdots_fluid_max;

     double safetyfactor = 0.999999;
     if(safetyfactor*LHS < RHS) {
       double rfactm1 = sqrt((safetyfactor*LHS)/RHS);
       mhd_st_x[index]=mhd_st_x[index]*rfactm1;
       mhd_st_y[index]=mhd_st_y[index]*rfactm1;
       mhd_st_z[index]=mhd_st_z[index]*rfactm1;
     }
   }
  


  return 0;
}

void recompute_conservatives_fast(struct output_primitives &new_primitives,
				  double &Psi6,double &alpha,
				  double &gxx_phys,double &gxy_phys,double &gxz_phys,double &gyy_phys,double &gyz_phys,double &gzz_phys,
				  double &gupxx_phys,double &gupxy_phys,double &gupxz_phys,double &gupyy_phys,double &gupyz_phys,double &gupzz_phys,
				  double &Bx,double &By,double &Bz,
				  double &rho_star,double &tau,double &mhd_st_x,double &mhd_st_y,double &mhd_st_z,
				  double &u_xl,double &u_yl, double &u_zl,double &au0m1) {
  
  double rho_b_new = new_primitives.rho_b_new;
  double P_new     = new_primitives.P_new;

  /*
    double vx_new     = new_primitives.vx_new;
    double vy_new     = new_primitives.vy_new;
    double vz_new     = new_primitives.vz_new;
  */
  double u0_new     = new_primitives.u0_new;

  //Recalculate eps & h_new:
  double eps = P_new/(GAMMA - 1.0)/rho_b_new;
  double h_new = 1.0 + P_new/rho_b_new + eps;

  double alpn1     = alpha;
  double alpn1_inv = 1.0/alpha;
  double f1o4p     = 1.0/(4.0*M_PI);
  double f1o4pa    = sqrt(f1o4p)*alpn1_inv;

  double Bx_f1o4pa = Bx*f1o4pa;
  double By_f1o4pa = By*f1o4pa;
  double Bz_f1o4pa = Bz*f1o4pa;
  
  double B_xl  = (gxx_phys *Bx + gxy_phys * By +
		  gxz_phys * Bz );
  double B_yl  = (gxy_phys *Bx + gyy_phys * By +
		  gyz_phys * Bz);
  double B_zl  = (gxz_phys *Bx + gyz_phys * By +
		  gzz_phys * Bz);
  double B_xl_f1o4pa = B_xl*f1o4pa;
  double B_yl_f1o4pa = B_yl*f1o4pa;
  double B_zl_f1o4pa = B_zl*f1o4pa;

  double B2 = ( gxx_phys*SQR(Bx_f1o4pa) +
		2.0*gxy_phys*Bx_f1o4pa*By_f1o4pa + 2.0*gxz_phys*Bx_f1o4pa*Bz_f1o4pa +
		gyy_phys*SQR(By_f1o4pa) + 2.0*gyz_phys*By_f1o4pa*Bz_f1o4pa +
		gzz_phys*SQR(Bz_f1o4pa) );
	
  double sb0 = u_xl*Bx_f1o4pa + u_yl*By_f1o4pa + u_zl*Bz_f1o4pa;
  double sb2 = (B2 + SQR(sb0))/SQR(u0_new);
  double sb_x = (B_xl_f1o4pa + u_xl*sb0)/u0_new;
  double sb_y = (B_yl_f1o4pa + u_yl*sb0)/u0_new;
  double sb_z = (B_zl_f1o4pa + u_zl*sb0)/u0_new;

  /*
    double tau_old = tau;
    double mhd_st_x_old = mhd_st_x;
  */

  rho_star = alpn1*u0_new*rho_b_new*Psi6;
  mhd_st_x = rho_star*h_new*u_xl +
    alpn1*Psi6*u0_new*sb2*u_xl - alpn1*Psi6*sb0*sb_x;
  mhd_st_y = rho_star*h_new*u_yl +
    alpn1*Psi6*u0_new*sb2*u_yl - alpn1*Psi6*sb0*sb_y;
  mhd_st_z = rho_star*h_new*u_zl +
    alpn1*Psi6*u0_new*sb2*u_zl - alpn1*Psi6*sb0*sb_z;
  tau = (au0m1+(P_new/rho_b_new+eps)*alpn1*u0_new)*rho_star +
    Psi6*sb2*SQR(alpn1*u0_new)
    - Psi6*(P_new+sb2*0.5)-Psi6*SQR(alpn1*sb0);

  /*
    if(tau>10) {
    printf("BADTAU: tau %e term1: %e term2: %e term3: %e u0new: %e au0m1: %e %e %e %e %e\n",tau,(au0m1+(P_new/rho_b_new+eps)*alpn1*u0_new)*rho_star,Psi6*sb2*SQR(alpn1*u0_new),-Psi6*(P_new+sb2*0.5)-Psi6*SQR(alpn1*sb0),u0_new,au0m1,sb2,sb0,B2,Bx);
    printf("%e %e %e %e %e %e\n",gxx_phys,gxy_phys,gxz_phys,gyy_phys,gyz_phys,gzz_phys);
    }
  */

}

