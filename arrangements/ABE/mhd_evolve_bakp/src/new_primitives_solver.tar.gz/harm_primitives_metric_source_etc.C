// Here is a wrapper for the 2d solver described in Noble et al.  
// It is meant to be an interface with their code.
// Note that it assumes a simple gamma law for the moment.  No hybrid.
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sys/time.h>
#include <math.h>
#include "cctk.h"
#include "harm_u2p_defs.h"

extern "C" void CCTK_FCALL CCTK_FNAME(metric_source_terms_and_misc_vars)
  (const cGH **cctkGH,int *ext,
   double *rho,double *Sx,double *Sy,double *Sz,
   double *Sxx,double *Sxy,double *Sxz,double *Syy,double *Syz,double *Szz,
   double *h,double *w,
   double *st_x,double *st_y,double *st_z,
   double *Ex,double *Ey,double *Ez,
   double *sbt,double *sbx,double *sby,double *sbz,
   double *lapm1,double *shiftx,double *shifty,double *shiftz,
   double *phi,double *gxx,double *gxy,double *gxz,double *gyy,double *gyz,double *gzz,
   double *gupxx,double *gupxy,double *gupxz,double *gupyy,double *gupyz,double *gupzz,
   double *P,double *rho_b,double *u0,double *vx,double *vy,double *vz,
   double *Bx,double *By,double *Bz,
   double *rho_star,double *mhd_st_x,double *mhd_st_y,double *mhd_st_z);

void metric_source_terms_and_misc_vars(const cGH *cctkGH,int *ext,double *rho,double *Sx,double *Sy,double *Sz,
				       double *Sxx,double *Sxy,double *Sxz,double *Syy,double *Syz,double *Szz,
				       double *h,double *w,
				       double *st_x,double *st_y,double *st_z,
				       double *Ex,double *Ey,double *Ez,
				       double *sbt,double *sbx,double *sby,double *sbz,
				       double *lapm1,double *shiftx,double *shifty,double *shiftz,
				       double *phi,double *gxx,double *gxy,double *gxz,double *gyy,double *gyz,double *gzz,
				       double *gupxx,double *gupxy,double *gupxz,double *gupyy,double *gupyz,double *gupzz,
				       double *P,double *rho_b,double *u0,double *vx,double *vy,double *vz,
				       double *Bx,double *By,double *Bz,
				       double *rho_star,double *mhd_st_x,double *mhd_st_y,double *mhd_st_z) {
#pragma omp parallel for
  for(int k=0;k<ext[2];k++)
    for(int j=0;j<ext[1];j++)
      for(int i=0;i<ext[0];i++) {
	int index = CCTK_GFINDEX3D(cctkGH,i,j,k);

	double alpn1 = lapm1[index] + 1.0;
	double alpn1_inv = 1.0/alpn1;

	double u0L = u0[index];

	double PL = P[index];
	double rho_bL = rho_b[index];
	double eps = h[index] - 1.0 - PL/rho_bL;

	double Psi2 = exp(2.0*phi[index]);
	double Psi4 = Psi2*Psi2;
	double Psim4 = 1.0/Psi4;
	double Psi6 = Psi4*Psi2;
	double Psim6 = 1.0/Psi6;

	double rho_starL = rho_star[index];
	
	double gxxL = gxx[index];
	double gxyL = gxy[index];
	double gxzL = gxz[index];
	double gyyL = gyy[index];
	double gyzL = gyz[index];
	double gzzL = gzz[index];

	double shiftxL = shiftx[index];
	double shiftyL = shifty[index];
	double shiftzL = shiftz[index];


	double u_xll = (gxxL*(shiftxL+vx[index]) + 
			gxyL*(shiftyL+vy[index]) + 
			gxzL*(shiftzL+vz[index]))*Psi4*u0L;
	double u_yll = (gxyL*(shiftxL+vx[index]) + 
			gyyL*(shiftyL+vy[index]) + 
			gyzL*(shiftzL+vz[index]))*Psi4*u0L;
	double u_zll = (gxzL*(shiftxL+vx[index]) + 
			gyzL*(shiftyL+vy[index]) + 
			gzzL*(shiftzL+vz[index]))*Psi4*u0L;

	double u_xl = u_xll;
	double u_yl = u_yll;
	double u_zl = u_zll;

	w[index] = (1.0+lapm1[index])*u0L*rho_starL;
	double st_x_l = rho_starL*h[index]*u_xl;
	double st_y_l = rho_starL*h[index]*u_yl;
	double st_z_l = rho_starL*h[index]*u_zl;

	st_x[index] = st_x_l;
	st_y[index] = st_y_l;
	st_z[index] = st_z_l;

	double ux_l = vx[index]*u0L;
	double uy_l = vy[index]*u0L;
	double uz_l = vz[index]*u0L;

	double fac   = 1.0 / ( Psi6 * w[index]* h[index] ) ;

	rho[index] = h[index] * w[index] * Psim6 - PL;
	Sx[index]  = st_x_l * Psim6;
	Sy[index]  = st_y_l * Psim6; 
	Sz[index]  = st_z_l * Psim6;
	Sxx[index] = fac * st_x_l*st_x_l + Psi4 * gxxL * PL;
	Sxy[index] = fac * st_x_l*st_y_l + Psi4 * gxyL * PL;
	Sxz[index] = fac * st_x_l*st_z_l + Psi4 * gxzL * PL;
	Syy[index] = fac * st_y_l*st_y_l + Psi4 * gyyL * PL;
	Syz[index] = fac * st_y_l*st_z_l + Psi4 * gyzL * PL;
	Szz[index] = fac * st_z_l*st_z_l + Psi4 * gzzL * PL;

	// MHD metric sources
	double BxL = Bx[index];
	double ByL = By[index];
	double BzL = Bz[index];

	double E_xl = Psi6 * ( ByL*(vz[index]+shiftzL) 
			       - BzL*(vy[index]+shiftyL) )*alpn1_inv;
	double E_yl = Psi6 * ( BzL*(vx[index]+shiftxL) 
			       - BxL*(vz[index]+shiftzL) )*alpn1_inv;
	double E_zl = Psi6 * ( BxL*(vy[index]+shiftyL) 
			       - ByL*(vx[index]+shiftxL) )*alpn1_inv;
	Ex[index] = (gupxx[index]*E_xl + gupxy[index]*E_yl + 
		     gupxz[index]*E_zl)*Psim4;
	Ey[index] = (gupxy[index]*E_xl + gupyy[index]*E_yl + 
		     gupyz[index]*E_zl)*Psim4;
	Ez[index] = (gupxz[index]*E_xl + gupyz[index]*E_yl + 
		     gupzz[index]*E_zl)*Psim4;
	double B_xl  = Psi4 * (gxxL * BxL + gxyL * ByL 
			       + gxzL * BzL);
	double B_yl  = Psi4 * (gxyL * BxL + gyyL * ByL 
			       + gyzL * BzL);
	double B_zl  = Psi4 * (gxzL * BxL + gyzL * ByL 
			       + gzzL * BzL);
	double f1o8p = 1.0/(8.0*M_PI);
	double f1o4p = 2.0*f1o8p;
	double temp = f1o8p*(Ex[index]*E_xl + Ey[index]*E_yl + Ez[index]*E_zl 
			     + BxL*B_xl + ByL*B_yl + BzL*B_zl);
	rho[index]   = rho[index] + temp;
	Sxx[index]   = Sxx[index] + temp*Psi4*gxxL 
	  - f1o4p*(E_xl*E_xl + B_xl*B_xl);
	Sxy[index]   = Sxy[index] + temp*Psi4*gxyL 
	  - f1o4p*(E_xl*E_yl + B_xl*B_yl);
	Sxz[index]   = Sxz[index] + temp*Psi4*gxzL 
	  - f1o4p*(E_xl*E_zl + B_xl*B_zl);
	Syy[index]   = Syy[index] + temp*Psi4*gyyL 
	  - f1o4p*(E_yl*E_yl + B_yl*B_yl);
	Syz[index]   = Syz[index] + temp*Psi4*gyzL 
	  - f1o4p*(E_yl*E_zl + B_yl*B_zl);
	Szz[index]   = Szz[index] + temp*Psi4*gzzL 
	  - f1o4p*(E_zl*E_zl + B_zl*B_zl);
	Sx[index]    = Sx[index] + f1o4p*Psi6*(Ey[index]*BzL - Ez[index]*ByL);
	Sy[index]    = Sy[index] + f1o4p*Psi6*(Ez[index]*BxL - Ex[index]*BzL);
	Sz[index]    = Sz[index] + f1o4p*Psi6*(Ex[index]*ByL - Ey[index]*BxL);
	sbt[index] = u_xll*BxL + u_yll*ByL + u_zll*BzL;
	sbx[index] = BxL/u0L + vx[index]*sbt[index];
	sby[index] = ByL/u0L + vy[index]*sbt[index];
	sbz[index] = BzL/u0L + vz[index]*sbt[index];

	if(isnan(Sx[index])) { printf("BAD sx: %d %d %d %e.  %e %e %e %e %e %e %e %e %e %e\n",
				      i,j,k,Sx[index],Psi6,Ey[index],BzL,Ez[index],ByL,rho_starL,h[index],u_xl,PL,rho_bL); exit(1); }
      }
}


extern "C" void CCTK_FCALL CCTK_FNAME(metric_source_terms_and_misc_vars)
  (const cGH **cctkGH,int *ext,
   double *rho,double *Sx,double *Sy,double *Sz,
   double *Sxx,double *Sxy,double *Sxz,double *Syy,double *Syz,double *Szz,
   double *h,double *w,
   double *st_x,double *st_y,double *st_z,
   double *Ex,double *Ey,double *Ez,
   double *sbt,double *sbx,double *sby,double *sbz,
   double *lapm1,double *shiftx,double *shifty,double *shiftz,
   double *phi,double *gxx,double *gxy,double *gxz,double *gyy,double *gyz,double *gzz,
   double *gupxx,double *gupxy,double *gupxz,double *gupyy,double *gupyz,double *gupzz,
   double *P,double *rho_b,double *u0,double *vx,double *vy,double *vz,
   double *Bx,double *By,double *Bz,
   double *rho_star,double *mhd_st_x,double *mhd_st_y,double *mhd_st_z) {
  metric_source_terms_and_misc_vars (*cctkGH,ext,
				     rho,Sx,Sy,Sz,
				     Sxx,Sxy,Sxz,Syy,Syz,Szz,
				     h,w,
				     st_x,st_y,st_z,
				     Ex,Ey,Ez,
				     sbt,sbx,sby,sbz,
				     lapm1,shiftx,shifty,shiftz,
				     phi,gxx,gxy,gxz,gyy,gyz,gzz,
				     gupxx,gupxy,gupxz,gupyy,gupyz,gupzz,
				     P,rho_b,u0,vx,vy,vz,
				     Bx,By,Bz,
				     rho_star,mhd_st_x,mhd_st_y,mhd_st_z);

}
