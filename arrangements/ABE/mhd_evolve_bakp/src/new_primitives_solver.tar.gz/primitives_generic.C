// Here is a wrapper for the 2d solver described in Noble et al.  
// It is meant to be an interface with their code.
// Note that it assumes a simple gamma law for the moment.  No hybrid.
#include <iostream>
#include <iomanip>
#include <fstream>
#include <time.h>
#include <sys/time.h>
#include <math.h>
#include "cctk.h"

#include "harm_primitives_headers.h"

#define SQR(x) ((x) * (x))

extern "C" void CCTK_FCALL CCTK_FNAME(primitives_generic)
  (const cGH **cctkGH,int *ext,int *nghostzones,double *X,double *Y,double *Z,
   double *phi,double *gxx,double *gxy,double *gxz,double *gyy,double *gyz,double *gzz,
   double *gupxx,double *gupxy,double *gupxz,double *gupyy,double *gupyz,double *gupzz,
   double *lapm1,double *shiftx,double *shifty,double *shiftz,
   double *Bx,double *By,double *Bz,
   double *mhd_st_x,double *mhd_st_y,double *mhd_st_z,double *tau,double *rho_star,
   double *vx,double *vy,double *vz,double *P,double *rho_b,double *h,double *u0,
   double &rhobatm,double &tau_atm,
   int &neos,double *rho_tab,double *P_tab,double *eps_tab,double *k_tab,double *gamma_tab,
   double *mhd_st_x_old,double *mhd_st_y_old,double *mhd_st_z_old,double *tau_old,double *rho_star_old,
   int &primitives_debug,double &Psi6threshold);

void primitives_generic(const cGH *cctkGH,int *ext,int *nghostzones,double *X,double *Y,double *Z,
			double *phi,double *gxx,double *gxy,double *gxz,double *gyy,double *gyz,double *gzz,
			double *gupxx,double *gupxy,double *gupxz,double *gupyy,double *gupyz,double *gupzz,
			double *lapm1,double *shiftx,double *shifty,double *shiftz,
			double *Bx,double *By,double *Bz,
			double *mhd_st_x,double *mhd_st_y,double *mhd_st_z,double *tau,double *rho_star,
			double *vx,double *vy,double *vz,double *P,double *rho_b,double *h,double *u0,
			double &rhobatm,double &tau_atm,
			int &neos,double *rho_tab,double *P_tab,double *eps_tab,double *k_tab,double *gamma_tab,
			double *mhd_st_x_old,double *mhd_st_y_old,double *mhd_st_z_old,double *tau_old,double *rho_star_old,
			int &primitives_debug,double &Psi6threshold) {
  
  using namespace std;

  //Start the timer, so we can benchmark the primitives solver during evolution.
  //  Slower solver -> harder to find roots -> things may be going crazy!
  struct timeval start, end;
  long mtime, seconds, useconds;
  gettimeofday(&start, NULL);

  int failures=0,font_fixes=0;
  int pointcount=0;
  int failures_inhoriz=0;
  int pointcount_inhoriz=0;

  if (fabs(gamma_tab[0]-GAMMA) > 1.e-10) {
     printf("GAMMA must be equal to gamma_tab[0]");
     exit(1);
  }

  int pressure_cap_hit=0;

  double error_int_numer=0,error_int_denom=0;
  
#pragma omp parallel for reduction(+:failures,font_fixes,pointcount,failures_inhoriz,pointcount_inhoriz,error_int_numer,error_int_denom,pressure_cap_hit) schedule(static)
  for(int k=0;k<ext[2];k++)
    for(int j=0;j<ext[1];j++)
      for(int i=0;i<ext[0];i++) {
	int index = CCTK_GFINDEX3D(cctkGH,i,j,k);

	struct output_primitives new_primitives;
	struct output_stats stats;

	if(isnan(tau[index])) { printf("found nan in tau %d %d %d\n",i,j,k); }
	if(isnan(mhd_st_x[index])) { printf("found nan in msx %d %d %d\n",i,j,k); }
	if(isnan(mhd_st_y[index])) { printf("found nan in msy %d %d %d\n",i,j,k); }
	if(isnan(mhd_st_z[index])) { printf("found nan in msz %d %d %d\n",i,j,k); }

	/*
	if(isnan(Bx[index])) { printf("found nan in Bx %d %d %d\n",i,j,k); }
	if(isnan(By[index])) { printf("found nan in By %d %d %d\n",i,j,k); }
	if(isnan(Bz[index])) { printf("found nan in Bz %d %d %d\n",i,j,k); exit(1); }
	*/
	if(isnan(rho_star[index])) { printf("found nan in rho_star %d %d %d\n",i,j,k); }

	tau_old[index] = tau[index];
	rho_star_old[index] = rho_star[index];
	mhd_st_x_old[index] = mhd_st_x[index];
	mhd_st_y_old[index] = mhd_st_y[index];
	mhd_st_z_old[index] = mhd_st_z[index];

	int rho_star_fix_applied=0;
	if(rho_star[index]<=0.0) {
	  // ZACH SAYS: This should happen RARELY.
	  double rho_sL=0;
	  double average=0;
	  int numpts=0;
	  if(i>0) { rho_sL=rho_star[CCTK_GFINDEX3D(cctkGH,i-1,j,k)]; if(rho_sL>0) { average+=rho_sL; numpts++; } }
	  if(j>0) { rho_sL=rho_star[CCTK_GFINDEX3D(cctkGH,i,j-1,k)]; if(rho_sL>0) { average+=rho_sL; numpts++; } }
	  if(k>0) { rho_sL=rho_star[CCTK_GFINDEX3D(cctkGH,i,j,k-1)]; if(rho_sL>0) { average+=rho_sL; numpts++; } }
	  if(i<ext[0]-1) { rho_sL=rho_star[CCTK_GFINDEX3D(cctkGH,i+1,j,k)]; if(rho_sL>0) { average+=rho_sL; numpts++; } }
	  if(j<ext[1]-1) { rho_sL=rho_star[CCTK_GFINDEX3D(cctkGH,i,j+1,k)]; if(rho_sL>0) { average+=rho_sL; numpts++; } }
	  if(k<ext[2]-1) { rho_sL=rho_star[CCTK_GFINDEX3D(cctkGH,i,j,k+1)]; if(rho_sL>0) { average+=rho_sL; numpts++; } }
	  if(average<=0) { numpts=1; average=(lapm1[index]+1)*1.0*rhobatm*exp(6.0*phi[index]); } // ZACH SAYS: This should happen EXTREMELY RARELY.
	  rho_star[index] = average/((double)numpts);
	  rho_star_fix_applied=1;
	}

	// Apply the tau floor
	apply_tau_floor(index,tau_atm,rhobatm,
			Bx,By,Bz,
			tau,rho_star,mhd_st_x,mhd_st_y,mhd_st_z,
			phi,gxx,gxy,gxz,gyy,gyz,gzz,
			gupxx,gupxy,gupxz,gupyy,gupyz,gupzz, 
			new_primitives,
			lapm1,shiftx,shifty,shiftz,
			neos,rho_tab,P_tab,eps_tab,k_tab,gamma_tab,
			Psi6threshold);
	
	double tau_orig = tau[index];
	double rho_star_orig = rho_star[index];
	double mhd_st_x_orig = mhd_st_x[index];
	double mhd_st_y_orig = mhd_st_y[index];
	double mhd_st_z_orig = mhd_st_z[index];

	if(isnan(tau[index])) { printf("2found nan in tau %d %d %d\n",i,j,k); }
	//if(isnan(mhd_st_x[index])) { printf("2found nan in msx %d %d %d\n",i,j,k); exit(1); }
	//if(isnan(mhd_st_y[index])) { printf("2found nan in msy %d %d %d\n",i,j,k); exit(1); }
	//if(isnan(mhd_st_z[index])) { printf("2found nan in msz %d %d %d\n",i,j,k); exit(1); }
	//if(isnan(rho_star[index])) { printf("2found nan in rho_star %d %d %d\n",i,j,k); exit(1); }

	/*
	  if(isnan(rho_b[index])) rho_b[index]=rhobatm;
	  if(isnan(P[index])) P[index]=0.0;
	  if(isnan(vx[index])) vx[index]=0.0;
	  if(isnan(vy[index])) vy[index]=0.0;
	  if(isnan(vz[index])) vz[index]=0.0;
	  if(isnan(u0[index])) u0[index]=1.0;
	*/

	int check=0;
	stats.font_fixed=0;
	for(int i=0;i<3;i++) {
	  check = harm_primitives_gammalaw_lowlevel(index,X,Y,Z,
						    phi,gxx,gxy,gxz,gyy,gyz,gzz,
						    gupxx,gupxy,gupxz,gupyy,gupyz,gupzz,
						    lapm1,shiftx,shifty,shiftz,
						    Bx,By,Bz,
						    mhd_st_x,mhd_st_y,mhd_st_z,tau,rho_star,
						    vx,vy,vz,P,rho_b,h,u0,
						    rhobatm,tau_atm,
						    neos,rho_tab,P_tab,eps_tab,k_tab,gamma_tab,			      
						    new_primitives,stats,Psi6threshold);
	  
	    // Set primitives, and/or provide a better guess.
	  P[index] = new_primitives.P_new;
	  rho_b[index] = new_primitives.rho_b_new;
	  u0[index] = new_primitives.u0_new;
	  vx[index] = new_primitives.vx_new;
	  vy[index] = new_primitives.vy_new;
	  vz[index] = new_primitives.vz_new;
	  
	  if(check==0) i=4;
	}
	

	//Finally, we set h, the enthalpy:
	double eps = P[index]/rho_b[index]/(GAMMA-1.0);
	h[index] = 1.0 + P[index]/rho_b[index] + eps;

	/***************************************************************************************************************************/
	// DIAGNOSTICS:
	//Pressure cap hit?
	double P_cold = rho_b[index]*rho_b[index];
	if(exp(phi[index]*6.0) > Psi6threshold) {
	  //if(P[index]/P_cold > 0.99*1e6) pressure_cap_hit++;
	} else {
	  if(P[index]/P_cold > 0.99*1e3 && rho_b[index]>100.0*rhobatm) pressure_cap_hit++;
	}

        //Now we compute the difference between original & new conservatives, for diagnostic purposes:
        error_int_numer += fabs(tau[index] - tau_orig) + fabs(rho_star[index] - rho_star_orig) + 
          fabs(mhd_st_x[index] - mhd_st_x_orig) + fabs(mhd_st_y[index] - mhd_st_y_orig) + fabs(mhd_st_z[index] - mhd_st_z_orig);
        error_int_denom += tau_orig + rho_star_orig + fabs(mhd_st_x_orig) + fabs(mhd_st_y_orig) + fabs(mhd_st_z_orig);

	if(stats.font_fixed==1) font_fixes++;
        if(check!=0) failures++;
        pointcount++;
        if(exp(phi[index]*6.0)>15.0) {
          if(check!=0) failures_inhoriz++;
          pointcount_inhoriz++;
        }
	/***************************************************************************************************************************/
	

      }

  gettimeofday(&end, NULL);

  seconds  = end.tv_sec  - start.tv_sec;
  useconds = end.tv_usec - start.tv_usec;

  mtime = ((seconds) * 1000 + useconds/1000.0) + 0.999;  // We add 0.999 since mtime is a long int; this rounds up the result before setting the value.  Here, rounding down is incorrect.
  printf("Font fixes: %d / %d = %.3e\tFailures: %d / %d = %.3e, InHoriz: %d / %d = %.3e\t%f solutions/second, Error: %e, ErrDenom: %e\n",
         font_fixes,pointcount,font_fixes/((double)pointcount), 
         failures,pointcount,failures/((double)pointcount), 
         failures_inhoriz,pointcount_inhoriz,failures_inhoriz/((double)pointcount_inhoriz+1e-10), 
         ext[0]*ext[1]*ext[2] / ((double)mtime/1000.0),
         error_int_numer/error_int_denom,error_int_denom);

  if(pressure_cap_hit!=0) {
    //printf("PRESSURE CAP HIT %d TIMES!  Outputting debug file!\n",pressure_cap_hit);
  }



  //if(pressure_cap_hit!=0 || (primitives_debug==1 && (failures>0 || error_int_numer/error_int_denom>0.8))) {
  //if((primitives_debug==1 && (failures>0 || error_int_numer/error_int_denom>0.8))) {
  if(primitives_debug==1) {

    ofstream myfile;
    char filename[100];
    srand(time(NULL));
    sprintf(filename,"primitives_debug-%d.dat",rand());
    myfile.open (filename, ios::out | ios::binary);
    //myfile.open ("data.bin", ios::out | ios::binary);
    myfile.write((char*)ext, 3*sizeof(int));

    myfile.write((char*)&rhobatm, 1*sizeof(double));
    myfile.write((char*)&tau_atm, 1*sizeof(double));

    myfile.write((char*)&Psi6threshold, 1*sizeof(double));

    double gamma_th=2.0;
    myfile.write((char*)&gamma_th, 1*sizeof(double));
    myfile.write((char*)&neos,     1*sizeof(int));

    myfile.write((char*)gamma_tab, (neos+1)*sizeof(double));
    myfile.write((char*)k_tab,     (neos+1)*sizeof(double));

    myfile.write((char*)eps_tab,   neos*sizeof(double));
    myfile.write((char*)rho_tab,   neos*sizeof(double));
    myfile.write((char*)P_tab,     neos*sizeof(double));

    int fullsize=ext[0]*ext[1]*ext[2];
    myfile.write((char*)X,   (fullsize)*sizeof(double));
    myfile.write((char*)Y,   (fullsize)*sizeof(double));
    myfile.write((char*)Z,   (fullsize)*sizeof(double));
    myfile.write((char*)phi, (fullsize)*sizeof(double));
    myfile.write((char*)gxx, (fullsize)*sizeof(double));
    myfile.write((char*)gxy, (fullsize)*sizeof(double));
    myfile.write((char*)gxz, (fullsize)*sizeof(double));
    myfile.write((char*)gyy, (fullsize)*sizeof(double));
    myfile.write((char*)gyz, (fullsize)*sizeof(double));
    myfile.write((char*)gzz, (fullsize)*sizeof(double));

    myfile.write((char*)gupxx, (fullsize)*sizeof(double));
    myfile.write((char*)gupxy, (fullsize)*sizeof(double));
    myfile.write((char*)gupxz, (fullsize)*sizeof(double));
    myfile.write((char*)gupyy, (fullsize)*sizeof(double));
    myfile.write((char*)gupyz, (fullsize)*sizeof(double));
    myfile.write((char*)gupzz, (fullsize)*sizeof(double));

    myfile.write((char*)shiftx, (fullsize)*sizeof(double));
    myfile.write((char*)shifty, (fullsize)*sizeof(double));
    myfile.write((char*)shiftz, (fullsize)*sizeof(double));

    myfile.write((char*)lapm1, (fullsize)*sizeof(double));
 
    myfile.write((char*)tau_old,      (fullsize)*sizeof(double));
    myfile.write((char*)mhd_st_x_old, (fullsize)*sizeof(double));
    myfile.write((char*)mhd_st_y_old, (fullsize)*sizeof(double));
    myfile.write((char*)mhd_st_z_old, (fullsize)*sizeof(double));

    myfile.write((char*)rho_star_old, (fullsize)*sizeof(double));

    myfile.write((char*)Bx,   (fullsize)*sizeof(double));
    myfile.write((char*)By,   (fullsize)*sizeof(double));
    myfile.write((char*)Bz,   (fullsize)*sizeof(double));

    myfile.write((char*)vx,   (fullsize)*sizeof(double));
    myfile.write((char*)vy,   (fullsize)*sizeof(double));
    myfile.write((char*)vz,   (fullsize)*sizeof(double));
    myfile.write((char*)P,    (fullsize)*sizeof(double));
    myfile.write((char*)rho_b,(fullsize)*sizeof(double));
    myfile.write((char*)h,    (fullsize)*sizeof(double));
    myfile.write((char*)u0,   (fullsize)*sizeof(double));

    int checker=1063; myfile.write((char*)&checker,sizeof(int));

    myfile.close();
    printf("Finished writing...\n");
    //sleep(2);
    //exit(1);
  }



}

#include "harm_primitives_lowlevel.C"

extern "C" void CCTK_FCALL CCTK_FNAME(primitives_generic)
  (const cGH **cctkGH,int *ext,int *nghostzones,double *X,double *Y,double *Z,
   double *phi,double *gxx,double *gxy,double *gxz,double *gyy,double *gyz,double *gzz,
   double *gupxx,double *gupxy,double *gupxz,double *gupyy,double *gupyz,double *gupzz,
   double *lapm1,double *shiftx,double *shifty,double *shiftz,
   double *Bx,double *By,double *Bz,
   double *mhd_st_x,double *mhd_st_y,double *mhd_st_z,double *tau,double *rho_star,
   double *vx,double *vy,double *vz,double *P,double *rho_b,double *h,double *u0,
   double &rhobatm,double &tau_atm,
   int &neos,double *rho_tab,double *P_tab,double *eps_tab,double *k_tab,double *gamma_tab,
   double *mhd_st_x_old,double *mhd_st_y_old,double *mhd_st_z_old,double *tau_old,double *rho_star_old,
   int &primitives_debug,double &Psi6threshold) {

  primitives_generic(*cctkGH,ext,nghostzones,X,Y,Z,
		     phi,gxx,gxy,gxz,gyy,gyz,gzz,
		     gupxx,gupxy,gupxz,gupyy,gupyz,gupzz,
		     lapm1,shiftx,shifty,shiftz,
		     Bx,By,Bz,
		     mhd_st_x,mhd_st_y,mhd_st_z,tau,rho_star,
		     vx,vy,vz,P,rho_b,h,u0,
		     rhobatm,tau_atm,
		     neos,rho_tab,P_tab,eps_tab,k_tab,gamma_tab,
		     mhd_st_x_old,mhd_st_y_old,mhd_st_z_old,tau_old,rho_star_old,
		     primitives_debug,Psi6threshold);

}
