// TwoPunctures:  File  "utilities.h"; see gr-qc/0404056

#define Pi  3.14159265358979323846264338328
#define Pih 1.57079632679489661923132169164 // Pi/2
#define Piq 0.78539816339744830961566084582 // Pi/4

#define TINY 1.0e-20
#define SWAP(a,b) {temp=(a);(a)=(b);(b)=temp;}
#define NR_END 1
#define FREE_ARG char*

typedef struct DCOMPLEX {double r,i;} dcomplex;

void nrerror(char error_text[]);
int      *ivector( long nl,  long nh);
double   *dvector( long nl,  long nh);
int     **imatrix( long nrl, long nrh, long ncl, long nch);
double  **dmatrix( long nrl, long nrh, long ncl, long nch);
double ***d3tensor(long nrl, long nrh, long ncl, long nch, long ndl, long ndh);
void free_ivector(int       *v, long nl,  long nh);
void free_dvector(double    *v, long nl,  long nh);
void free_imatrix(int      **m, long nrl, long nrh, long ncl, long nch);
void free_dmatrix(double   **m, long nrl, long nrh, long ncl, long nch);
void free_d3tensor(double ***t, long nrl, long nrh, long ncl, long nch,
								long ndl, long ndh);

int minimum2(int i,int j);
int minimum3(int i,int j,int k);
int maximum2(int i,int j);
int maximum3(int i,int j,int k);
int pow_int(int mantisse,int exponent);
double atanhd(double x);
double asinhd(double x);
double acoshd(double x);

dcomplex Cadd(dcomplex a, dcomplex b);
dcomplex Csub(dcomplex a, dcomplex b);
dcomplex Cmul(dcomplex a, dcomplex b);
dcomplex RCmul(double x, dcomplex a);
dcomplex Cdiv(dcomplex a, dcomplex b);
dcomplex Complex(double re, double im);
dcomplex Conjg(dcomplex z);
double Cabs(dcomplex z);

dcomplex Csqrt(dcomplex z);
dcomplex Cexp(dcomplex z);
dcomplex Clog(dcomplex z);
dcomplex Csin(dcomplex z);
dcomplex Ccos(dcomplex z);
dcomplex Ctan(dcomplex z);
dcomplex Ccot(dcomplex z);
dcomplex Csinh(dcomplex z);
dcomplex Ccosh(dcomplex z);
dcomplex Ctanh(dcomplex z);
dcomplex Ccoth(dcomplex z);

void chebft_Zeros(double u[], int n, int inv);
void chebft_Extremes(double u[], int n, int inv);
void chder(double *c, double *cder, int n);
double chebev(double a, double b, double c[], int m, double x);
void fourft(double *u, int N, int inv);
void fourder(double u[], double du[], int N);
void fourder2(double u[], double d2u[], int N);
double fourev(double *u, int N, double x);


void ludcmp(double **a, int n, int *indx, double *d);
void lubksb(double **a, int n, int *indx, double b[]);
void tridag(double a[], double b[], double c[], double r[], double u[], int n);
double norm1(double *v, int n);
double norm2(double *v, int n);
double scalarproduct(double *v, double *w, int n);
void copy(double *aout, double *ain, int ntotal);
void fill0(double *dv, int ntotal);

double plgndr(int l, int m, double x);





